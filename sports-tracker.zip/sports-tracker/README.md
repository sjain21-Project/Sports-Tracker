# Sports Tracker

A web dashboard for following live scores across the sports I actually watch: the NFL, NBA, NCAA men's football and basketball, UFC, boxing, and my ESPN fantasy football league. It's a small Flask app that pulls from ESPN's public JSON feeds and refreshes on its own while games are in progress.

## Features

- Scoreboards for the NFL, NBA, NCAA football (FBS) and NCAA men's basketball (Division I), with live clocks, records, rankings, venues and TV info
- Full fight cards for UFC and boxing, listed main event first, with weight class and result for each bout
- ESPN fantasy football standings and weekly matchups with live point totals, including private leagues
- Browse any date, and filter by live, upcoming or final
- Polls every 30 seconds while something is live and every 2 minutes otherwise, and pauses when the tab isn't visible
- Server-side caching so several open tabs don't multiply requests to ESPN
- Works on mobile and follows the system light/dark setting

## Tech stack

Python 3.10+, Flask and requests on the backend. The frontend is plain HTML, CSS and JavaScript with no build step. Tests use pytest.

## Getting started

```bash
git clone https://github.com/<your-username>/sports-tracker.git
cd sports-tracker
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python run.py
```

Then open http://127.0.0.1:5000.

## Fantasy football setup

You can type a league ID into the Fantasy Football tab, or set a default in a `.env` file (see `.env.example`):

```
ESPN_FANTASY_LEAGUE_ID=123456
ESPN_FANTASY_SEASON=2026
```

The league ID is the `leagueId` value in the URL of your league page on ESPN. Public leagues work with just the ID. For a private league, sign in to espn.com, open your browser's developer tools, and copy the `espn_s2` and `SWID` cookies into `ESPN_S2` and `ESPN_SWID`. Keep these out of version control, since they act like a login.

## API

The dashboard is built on a small JSON API that can also be used directly.

| Endpoint | Description |
| --- | --- |
| `GET /api/leagues` | Supported leagues |
| `GET /api/scoreboard/<league>?date=YYYYMMDD` | Games or fight cards for `nfl`, `nba`, `ncaaf`, `ncaam`, `ufc` or `boxing`. Without a date, ESPN's current day or week is used. |
| `GET /api/fantasy?league_id=&week=&season=` | Fantasy standings and matchups. All parameters are optional when a league is configured. |
| `GET /api/health` | Health check |

## Project structure

```
sports_tracker/
    __init__.py        App factory
    config.py          Settings from environment variables
    leagues.py         League registry and ESPN paths
    models.py          Data models returned by the API
    routes.py          Page and API routes
    espn/
        client.py      HTTP client with timeout handling and a TTL cache
        parsers.py     Converts ESPN payloads into the models above
    templates/
    static/
tests/                 Parser, client and route tests with fixture data
run.py                 Development server
```

## Running tests

```bash
pip install -r requirements-dev.txt
pytest
```

The tests use saved fixture data and a fake client, so they don't make network calls.

## Deployment

Any WSGI server works. For example:

```bash
pip install gunicorn
gunicorn "sports_tracker:create_app()" --bind 0.0.0.0:8000
```

## Notes

ESPN doesn't officially document these endpoints, and the response format can change between sports or seasons. The parsers treat every field as optional so a missing value shows up as a blank rather than an error. Boxing coverage depends on what ESPN publishes, so some weeks may have no events.

This project is not affiliated with or endorsed by ESPN.

## Contact

Built by Samyak Jain. Questions or feedback are welcome at [21jsamyak@gmail.com](mailto:21jsamyak@gmail.com).

## License

MIT. See [LICENSE](LICENSE).
