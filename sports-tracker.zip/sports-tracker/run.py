"""Development entry point. Use a WSGI server such as gunicorn in production."""

import os

from dotenv import load_dotenv

from sports_tracker import create_app

load_dotenv()
app = create_app()

if __name__ == "__main__":
    app.run(
        host=os.getenv("HOST", "127.0.0.1"),
        port=int(os.getenv("PORT", "5000")),
        debug=os.getenv("FLASK_DEBUG") == "1",
    )
