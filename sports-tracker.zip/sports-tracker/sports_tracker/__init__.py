"""Live sports tracker: a Flask dashboard backed by ESPN's public data feeds."""

from __future__ import annotations

import logging

from flask import Flask

from .config import Settings
from .espn.client import ESPNClient

__version__ = "1.0.0"


def create_app(settings: Settings | None = None, client: ESPNClient | None = None) -> Flask:
    settings = settings or Settings.from_env()

    app = Flask(__name__)
    app.config["SETTINGS"] = settings
    app.extensions["espn_client"] = client or ESPNClient(
        timeout=settings.request_timeout, cache_ttl=settings.cache_ttl
    )

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

    from .routes import api, pages

    app.register_blueprint(pages)
    app.register_blueprint(api, url_prefix="/api")
    return app
