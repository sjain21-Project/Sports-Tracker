"""Settings read from environment variables, with defaults suited to local use."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from datetime import date


def _int_env(name: str, default: int | None) -> int | None:
    value = os.getenv(name, "").strip()
    return int(value) if value.isdigit() else default


def _default_fantasy_season() -> int:
    # The NFL season that starts in September runs into the next calendar year.
    today = date.today()
    return today.year if today.month >= 3 else today.year - 1


@dataclass(frozen=True)
class Settings:
    request_timeout: float = 10.0
    cache_ttl: float = 20.0
    fantasy_league_id: str | None = None
    fantasy_season: int = field(default_factory=_default_fantasy_season)
    espn_s2: str | None = None
    espn_swid: str | None = None

    @property
    def fantasy_configured(self) -> bool:
        return bool(self.fantasy_league_id)

    @classmethod
    def from_env(cls) -> Settings:
        return cls(
            request_timeout=float(os.getenv("REQUEST_TIMEOUT", "10")),
            cache_ttl=float(os.getenv("CACHE_TTL", "20")),
            fantasy_league_id=os.getenv("ESPN_FANTASY_LEAGUE_ID") or None,
            fantasy_season=_int_env("ESPN_FANTASY_SEASON", None) or _default_fantasy_season(),
            espn_s2=os.getenv("ESPN_S2") or None,
            espn_swid=os.getenv("ESPN_SWID") or None,
        )
