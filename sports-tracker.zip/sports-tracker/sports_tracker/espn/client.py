"""HTTP client for ESPN's public JSON endpoints, with a small in-memory cache."""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Mapping
from typing import Any

import requests

from ..leagues import League

logger = logging.getLogger(__name__)

SITE_API_BASE = "https://site.api.espn.com/apis/site/v2/sports"
FANTASY_API_BASE = "https://lm-api-reads.fantasy.espn.com/apis/v3/games/ffl"

USER_AGENT = "sports-tracker/1.0"


class ESPNError(RuntimeError):
    """Raised when ESPN cannot be reached or returns something unusable."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class TTLCache:
    """Thread-safe cache where every entry expires after a fixed number of seconds."""

    def __init__(self, ttl_seconds: float) -> None:
        self.ttl = ttl_seconds
        self._store: dict[Any, tuple[float, Any]] = {}
        self._lock = threading.Lock()

    def get(self, key: Any) -> Any | None:
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            expires_at, value = entry
            if time.monotonic() >= expires_at:
                del self._store[key]
                return None
            return value

    def set(self, key: Any, value: Any) -> None:
        with self._lock:
            self._store[key] = (time.monotonic() + self.ttl, value)

    def clear(self) -> None:
        with self._lock:
            self._store.clear()


class ESPNClient:
    def __init__(
        self,
        timeout: float = 10.0,
        cache_ttl: float = 20.0,
        session: requests.Session | None = None,
    ) -> None:
        self.timeout = timeout
        self.cache = TTLCache(cache_ttl)
        self.session = session or requests.Session()
        self.session.headers.setdefault("User-Agent", USER_AGENT)

    def get_json(
        self,
        url: str,
        params: Mapping[str, str] | None = None,
        cookies: Mapping[str, str] | None = None,
    ) -> dict[str, Any]:
        params = dict(params or {})
        cache_key = (url, tuple(sorted(params.items())), tuple(sorted((cookies or {}).items())))
        cached = self.cache.get(cache_key)
        if cached is not None:
            return cached

        try:
            response = self.session.get(
                url, params=params, cookies=dict(cookies or {}), timeout=self.timeout
            )
        except requests.RequestException as exc:
            logger.warning("Request to %s failed: %s", url, exc)
            raise ESPNError("Could not reach ESPN. Try again shortly.") from exc

        if response.status_code in (401, 403):
            raise ESPNError(
                "ESPN denied access. Private fantasy leagues need ESPN_S2 and ESPN_SWID.",
                response.status_code,
            )
        if not response.ok:
            raise ESPNError(f"ESPN returned HTTP {response.status_code}.", response.status_code)

        try:
            data = response.json()
        except ValueError as exc:
            raise ESPNError("ESPN returned a response that was not JSON.") from exc

        self.cache.set(cache_key, data)
        return data

    def scoreboard(self, league: League, date: str | None = None) -> dict[str, Any]:
        """Fetch the raw scoreboard for a league. ``date`` is YYYYMMDD."""
        params = dict(league.params)
        if date:
            params["dates"] = date
        return self.get_json(f"{SITE_API_BASE}/{league.scoreboard_path}", params)

    def fantasy_league(
        self,
        league_id: str,
        season: int,
        week: int | None = None,
        espn_s2: str | None = None,
        swid: str | None = None,
    ) -> dict[str, Any]:
        """Fetch team, standings and matchup data for an ESPN fantasy football league."""
        url = f"{FANTASY_API_BASE}/seasons/{season}/segments/0/leagues/{league_id}"
        params: dict[str, Any] = {"view": ["mTeam", "mMatchupScore", "mSettings", "mStandings"]}
        if week:
            params["scoringPeriodId"] = str(week)
        cookies = {}
        if espn_s2 and swid:
            cookies = {"espn_s2": espn_s2, "SWID": swid}
        return self.get_json(url, _flatten(params), cookies)


def _flatten(params: Mapping[str, Any]) -> dict[str, Any]:
    """requests accepts lists for repeated keys; keep them hashable for the cache key."""
    return {key: tuple(value) if isinstance(value, list) else value for key, value in params.items()}
