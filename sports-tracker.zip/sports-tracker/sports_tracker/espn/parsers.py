"""Turn ESPN scoreboard and fantasy payloads into the tracker's own models.

ESPN's feeds are undocumented and fields come and go between sports, so every
lookup here tolerates missing keys rather than assuming a fixed shape.
"""

from __future__ import annotations

from typing import Any

from ..models import (
    Bout,
    Competitor,
    FantasyLeague,
    FantasyMatchup,
    FantasyMatchupSide,
    FantasyTeam,
    FightCard,
    Game,
    Status,
)

Json = dict[str, Any]


def _first(items: list[Any] | None) -> Any | None:
    return items[0] if items else None


def _event_link(event: Json) -> str | None:
    for link in event.get("links") or []:
        if "summary" in (link.get("rel") or []) or "event" in (link.get("rel") or []):
            return link.get("href")
    first = _first(event.get("links"))
    return first.get("href") if first else None


def parse_status(raw: Json | None) -> Status:
    raw = raw or {}
    status_type = raw.get("type") or {}
    state = status_type.get("state") or "pre"
    detail = status_type.get("shortDetail") or status_type.get("detail") or status_type.get("description") or ""
    clock = raw.get("displayClock") if state == "in" else None
    period = raw.get("period") or None
    return Status(state=state, detail=detail, clock=clock, period=period)


def _record_summary(competitor: Json) -> str | None:
    records = competitor.get("records") or competitor.get("record") or []
    if isinstance(records, list):
        overall = next((r for r in records if r.get("type") in ("total", "overall")), _first(records))
        return overall.get("summary") if overall else None
    return None


def parse_team_competitor(raw: Json) -> Competitor:
    team = raw.get("team") or {}
    rank = (raw.get("curatedRank") or {}).get("current")
    return Competitor(
        name=team.get("displayName") or team.get("name") or "TBD",
        abbreviation=team.get("abbreviation"),
        logo=team.get("logo") or (_first(team.get("logos")) or {}).get("href"),
        score=raw.get("score"),
        record=_record_summary(raw),
        # ESPN uses 99 to mean "unranked".
        rank=rank if isinstance(rank, int) and 0 < rank < 99 else None,
        home_away=raw.get("homeAway"),
        winner=bool(raw.get("winner")),
    )


def parse_fighter(raw: Json) -> Competitor:
    athlete = raw.get("athlete") or {}
    flag = athlete.get("flag") or {}
    return Competitor(
        name=athlete.get("displayName") or athlete.get("fullName") or "TBD",
        abbreviation=athlete.get("shortName"),
        logo=flag.get("href"),
        score=None,
        record=_record_summary(raw),
        winner=bool(raw.get("winner")),
    )


def parse_game(event: Json) -> Game:
    competition = _first(event.get("competitions")) or {}
    competitors = [parse_team_competitor(c) for c in competition.get("competitors") or []]
    # Show the away team first, the way scoreboards are conventionally read.
    competitors.sort(key=lambda c: 0 if c.home_away == "away" else 1)

    broadcast_names: list[str] = []
    for broadcast in competition.get("broadcasts") or []:
        broadcast_names.extend(broadcast.get("names") or [])

    return Game(
        id=str(event.get("id", "")),
        name=event.get("shortName") or event.get("name") or "",
        start_time=event.get("date") or competition.get("date"),
        status=parse_status(competition.get("status") or event.get("status")),
        competitors=competitors,
        venue=(competition.get("venue") or {}).get("fullName"),
        broadcast=", ".join(broadcast_names) or None,
        link=_event_link(event),
    )


def _bout_result(competition: Json) -> str | None:
    status_type = (competition.get("status") or {}).get("type") or {}
    if status_type.get("state") != "post":
        return None
    method = status_type.get("detail") or status_type.get("shortDetail")
    result = (competition.get("status") or {}).get("result") or {}
    return result.get("displayName") or result.get("name") or method


def parse_bout(competition: Json) -> Bout:
    weight_class = (competition.get("type") or {}).get("text") or (competition.get("type") or {}).get("abbreviation")
    note = _first(competition.get("notes"))
    if not weight_class and note:
        weight_class = note.get("headline") or note.get("text")
    return Bout(
        id=str(competition.get("id", "")),
        weight_class=weight_class,
        status=parse_status(competition.get("status")),
        fighters=[parse_fighter(c) for c in competition.get("competitors") or []],
        result=_bout_result(competition),
    )


def parse_fight_card(event: Json) -> FightCard:
    competitions = event.get("competitions") or []
    # ESPN lists bouts from the first prelim upward; put the main event on top.
    bouts = [parse_bout(c) for c in reversed(competitions)]
    venue = None
    for competition in competitions:
        venue = (competition.get("venue") or {}).get("fullName")
        if venue:
            break
    return FightCard(
        id=str(event.get("id", "")),
        name=event.get("name") or event.get("shortName") or "",
        start_time=event.get("date"),
        status=parse_status(event.get("status")),
        bouts=bouts,
        venue=venue,
        link=_event_link(event),
    )


def parse_team_scoreboard(payload: Json) -> list[Game]:
    return [parse_game(event) for event in payload.get("events") or []]


def parse_combat_scoreboard(payload: Json) -> list[FightCard]:
    return [parse_fight_card(event) for event in payload.get("events") or []]


# Fantasy football ------------------------------------------------------------


def _fantasy_team_name(team: Json) -> str:
    if team.get("name"):
        return team["name"]
    combined = f"{team.get('location', '')} {team.get('nickname', '')}".strip()
    return combined or f"Team {team.get('id')}"


def parse_fantasy_league(payload: Json, league_id: str, week: int | None = None) -> FantasyLeague:
    teams_by_id: dict[int, str] = {}
    standings: list[FantasyTeam] = []

    for team in payload.get("teams") or []:
        team_id = int(team.get("id", 0))
        name = _fantasy_team_name(team)
        teams_by_id[team_id] = name
        overall = (team.get("record") or {}).get("overall") or {}
        standings.append(
            FantasyTeam(
                id=team_id,
                name=name,
                abbreviation=team.get("abbrev"),
                wins=int(overall.get("wins", 0)),
                losses=int(overall.get("losses", 0)),
                ties=int(overall.get("ties", 0)),
                points_for=round(float(overall.get("pointsFor", 0.0)), 2),
                points_against=round(float(overall.get("pointsAgainst", 0.0)), 2),
                seed=team.get("playoffSeed"),
                logo=team.get("logo"),
            )
        )

    standings.sort(key=lambda t: (t.seed if t.seed else 99, -t.wins, -t.points_for))

    current_week = week or (payload.get("status") or {}).get("currentMatchupPeriod") or payload.get("scoringPeriodId") or 1

    def side(raw: Json | None) -> FantasyMatchupSide | None:
        if not raw:
            return None
        team_id = int(raw.get("teamId", 0))
        live = raw.get("totalPointsLive")
        points = live if live is not None else raw.get("totalPoints", 0.0)
        return FantasyMatchupSide(
            team_id=team_id,
            team_name=teams_by_id.get(team_id, f"Team {team_id}"),
            points=round(float(points or 0.0), 2),
            projected=raw.get("totalProjectedPointsLive"),
        )

    matchups = [
        FantasyMatchup(
            id=int(m.get("id", 0)),
            week=int(m.get("matchupPeriodId", 0)),
            home=side(m.get("home")),
            away=side(m.get("away")),
            winner=m.get("winner") or "UNDECIDED",
        )
        for m in payload.get("schedule") or []
        if m.get("matchupPeriodId") == current_week
    ]

    settings = payload.get("settings") or {}
    return FantasyLeague(
        id=str(league_id),
        name=settings.get("name") or f"League {league_id}",
        season=int(payload.get("seasonId", 0)),
        week=int(current_week),
        standings=standings,
        matchups=matchups,
    )
