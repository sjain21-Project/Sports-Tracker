"""Registry of the leagues the tracker supports and how to reach them on ESPN."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class LeagueKind(str, Enum):
    """How a league's scoreboard is structured."""

    TEAM = "team"  # Two teams per game (NBA, NFL, NCAA).
    COMBAT = "combat"  # Fight cards made up of individual bouts (UFC, boxing).


@dataclass(frozen=True)
class League:
    key: str
    name: str
    sport_path: str
    kind: LeagueKind
    params: dict[str, str] = field(default_factory=dict)

    @property
    def scoreboard_path(self) -> str:
        return f"{self.sport_path}/scoreboard"

    def to_dict(self) -> dict[str, str]:
        return {"key": self.key, "name": self.name, "kind": self.kind.value}


LEAGUES: dict[str, League] = {
    league.key: league
    for league in (
        League("nfl", "NFL", "football/nfl", LeagueKind.TEAM),
        League("nba", "NBA", "basketball/nba", LeagueKind.TEAM),
        # groups=80 limits college football to FBS; groups=50 is Division I basketball.
        League(
            "ncaaf",
            "NCAA Football",
            "football/college-football",
            LeagueKind.TEAM,
            {"groups": "80", "limit": "300"},
        ),
        League(
            "ncaam",
            "NCAA Men's Basketball",
            "basketball/mens-college-basketball",
            LeagueKind.TEAM,
            {"groups": "50", "limit": "300"},
        ),
        League("ufc", "UFC", "mma/ufc", LeagueKind.COMBAT),
        League("boxing", "Boxing", "boxing/boxing", LeagueKind.COMBAT),
    )
}


def get_league(key: str) -> League | None:
    return LEAGUES.get(key.lower())
