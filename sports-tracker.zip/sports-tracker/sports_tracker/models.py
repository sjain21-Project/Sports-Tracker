"""Plain data models returned by the API. They are deliberately ESPN-agnostic."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class Competitor:
    name: str
    abbreviation: str | None = None
    logo: str | None = None
    score: str | None = None
    record: str | None = None
    rank: int | None = None
    home_away: str | None = None
    winner: bool = False


@dataclass
class Status:
    state: str  # "pre", "in" or "post"
    detail: str
    clock: str | None = None
    period: int | None = None


@dataclass
class Game:
    id: str
    name: str
    start_time: str | None
    status: Status
    competitors: list[Competitor]
    venue: str | None = None
    broadcast: str | None = None
    link: str | None = None


@dataclass
class Bout:
    id: str
    weight_class: str | None
    status: Status
    fighters: list[Competitor]
    result: str | None = None


@dataclass
class FightCard:
    id: str
    name: str
    start_time: str | None
    status: Status
    bouts: list[Bout] = field(default_factory=list)
    venue: str | None = None
    link: str | None = None


@dataclass
class FantasyTeam:
    id: int
    name: str
    abbreviation: str | None
    wins: int
    losses: int
    ties: int
    points_for: float
    points_against: float
    seed: int | None = None
    logo: str | None = None


@dataclass
class FantasyMatchupSide:
    team_id: int
    team_name: str
    points: float
    projected: float | None = None


@dataclass
class FantasyMatchup:
    id: int
    week: int
    home: FantasyMatchupSide | None
    away: FantasyMatchupSide | None
    winner: str  # "HOME", "AWAY", "TIE" or "UNDECIDED"


@dataclass
class FantasyLeague:
    id: str
    name: str
    season: int
    week: int
    standings: list[FantasyTeam]
    matchups: list[FantasyMatchup]


def serialize(obj: Any) -> Any:
    """Convert a model (or list of models) into JSON-friendly primitives."""
    if isinstance(obj, list):
        return [serialize(item) for item in obj]
    return asdict(obj)
