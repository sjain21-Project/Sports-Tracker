"""Page and JSON API routes."""

from __future__ import annotations

import re
from datetime import datetime, timezone

from flask import Blueprint, current_app, jsonify, render_template, request

from .config import Settings
from .espn import parsers
from .espn.client import ESPNClient, ESPNError
from .leagues import LEAGUES, LeagueKind, get_league
from .models import serialize

pages = Blueprint("pages", __name__)
api = Blueprint("api", __name__)

DATE_PATTERN = re.compile(r"^\d{8}$")


def _client() -> ESPNClient:
    return current_app.extensions["espn_client"]


def _settings() -> Settings:
    return current_app.config["SETTINGS"]


def _error(message: str, status: int):
    return jsonify({"error": message}), status


def _timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@pages.get("/")
def index():
    leagues = [league.to_dict() for league in LEAGUES.values()]
    leagues.append({"key": "fantasy", "name": "Fantasy Football", "kind": "fantasy"})
    return render_template("index.html", leagues=leagues)


@api.get("/leagues")
def list_leagues():
    return jsonify(
        {
            "leagues": [league.to_dict() for league in LEAGUES.values()],
            "fantasy_configured": _settings().fantasy_configured,
        }
    )


@api.get("/scoreboard/<league_key>")
def scoreboard(league_key: str):
    league = get_league(league_key)
    if league is None:
        return _error(f"Unknown league '{league_key}'.", 404)

    date = request.args.get("date")
    if date and not DATE_PATTERN.match(date):
        return _error("Date must be in YYYYMMDD format.", 400)

    try:
        payload = _client().scoreboard(league, date)
    except ESPNError as exc:
        return _error(str(exc), 502)

    if league.kind is LeagueKind.COMBAT:
        events = parsers.parse_combat_scoreboard(payload)
    else:
        events = parsers.parse_team_scoreboard(payload)

    return jsonify(
        {
            "league": league.to_dict(),
            "date": date,
            "updated_at": _timestamp(),
            "live": any(event.status.state == "in" for event in events),
            "events": serialize(events),
        }
    )


@api.get("/fantasy")
def fantasy():
    settings = _settings()
    league_id = request.args.get("league_id") or settings.fantasy_league_id
    if not league_id:
        return _error(
            "No fantasy league configured. Set ESPN_FANTASY_LEAGUE_ID or pass ?league_id=.", 400
        )
    if not league_id.isdigit():
        return _error("League ID must be numeric.", 400)

    week = request.args.get("week", type=int)
    season = request.args.get("season", type=int) or settings.fantasy_season

    try:
        payload = _client().fantasy_league(
            league_id, season, week, espn_s2=settings.espn_s2, swid=settings.espn_swid
        )
    except ESPNError as exc:
        status = 403 if exc.status_code in (401, 403) else 502
        return _error(str(exc), status)

    league = parsers.parse_fantasy_league(payload, league_id, week)
    return jsonify({"updated_at": _timestamp(), "league": serialize(league)})


@api.get("/health")
def health():
    return jsonify({"status": "ok"})
