"use strict";

(() => {
  const LIVE_REFRESH_MS = 30_000;
  const IDLE_REFRESH_MS = 120_000;
  const STORAGE_KEY = "sports-tracker:fantasy-league-id";

  const state = {
    league: null,
    kind: null,
    date: null, // YYYY-MM-DD, or null for ESPN's default (today / current week)
    filter: "all",
    timer: null,
    controller: null,
    lastScoreboard: null,
  };

  const el = {
    tabs: document.querySelectorAll(".tab"),
    content: document.getElementById("content"),
    updated: document.getElementById("updated"),
    datePicker: document.getElementById("date-picker"),
    todayBtn: document.getElementById("today-btn"),
    shiftBtns: document.querySelectorAll("[data-shift]"),
    chips: document.querySelectorAll(".chip"),
    scoreboardToolbar: document.getElementById("scoreboard-toolbar"),
    fantasyToolbar: document.getElementById("fantasy-toolbar"),
    fantasyForm: document.getElementById("fantasy-form"),
    fantasyLeagueId: document.getElementById("fantasy-league-id"),
    fantasyWeek: document.getElementById("fantasy-week"),
  };

  // Helpers -----------------------------------------------------------------

  const escapeHtml = (value) =>
    String(value ?? "").replace(/[&<>"']/g, (ch) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    })[ch]);

  const safeUrl = (url) => (typeof url === "string" && url.startsWith("https://") ? url : null);

  const toIsoDate = (d) =>
    `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;

  const formatStart = (iso) => {
    if (!iso) return "";
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return "";
    return d.toLocaleString(undefined, { weekday: "short", month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
  };

  const statusLabel = (status, startTime) => {
    if (status.state === "in") return `<span class="status-live">${escapeHtml(status.detail || "Live")}</span>`;
    if (status.state === "pre") return escapeHtml(formatStart(startTime) || status.detail);
    return escapeHtml(status.detail || "Final");
  };

  const setUpdated = (iso) => {
    el.updated.textContent = iso ? `Updated ${new Date(iso).toLocaleTimeString()}` : "";
  };

  const showMessage = (text, isError = false) => {
    el.content.innerHTML = `<div class="${isError ? "error" : "empty"}">${text}</div>`;
  };

  async function fetchJson(url) {
    if (state.controller) state.controller.abort();
    state.controller = new AbortController();
    const response = await fetch(url, { signal: state.controller.signal });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.error || `Request failed (${response.status})`);
    return body;
  }

  function scheduleRefresh(isLive) {
    clearTimeout(state.timer);
    state.timer = setTimeout(load, isLive ? LIVE_REFRESH_MS : IDLE_REFRESH_MS);
  }

  // Rendering ---------------------------------------------------------------

  function renderTeamRow(team, showScore, isLoser) {
    const logo = safeUrl(team.logo);
    const rank = team.rank ? `<span class="rank">${team.rank}</span>` : "";
    const record = team.record ? `<span class="team-meta">${escapeHtml(team.record)}</span>` : "";
    return `
      <div class="team-row${isLoser ? " is-loser" : ""}">
        ${logo ? `<img src="${escapeHtml(logo)}" alt="" loading="lazy">` : "<span></span>"}
        <span class="team-name">${rank}${escapeHtml(team.name)}${record}</span>
        <span class="score">${showScore ? escapeHtml(team.score ?? "") : ""}</span>
      </div>`;
  }

  function renderGame(game) {
    const { status } = game;
    const showScore = status.state !== "pre";
    const hasWinner = game.competitors.some((c) => c.winner);
    const rows = game.competitors
      .map((team) => renderTeamRow(team, showScore, status.state === "post" && hasWinner && !team.winner))
      .join("");
    const link = safeUrl(game.link);
    const footLeft = [game.broadcast, game.venue].filter(Boolean).map(escapeHtml).join(" &middot; ");
    return `
      <article class="card${status.state === "post" ? " is-final" : ""}">
        <div class="card-head">
          <span>${statusLabel(status, game.start_time)}</span>
          <span>${escapeHtml(game.name)}</span>
        </div>
        ${rows}
        ${footLeft || link ? `
        <div class="card-foot">
          <span>${footLeft}</span>
          ${link ? `<a href="${escapeHtml(link)}" target="_blank" rel="noopener">Details</a>` : ""}
        </div>` : ""}
      </article>`;
  }

  function renderFighter(fighter, side) {
    const record = fighter.record ? `<small>${escapeHtml(fighter.record)}</small>` : "";
    const badge = fighter.winner ? `<span class="badge">W</span>` : "";
    const name = side === "right" ? `${badge}${escapeHtml(fighter.name)}` : `${escapeHtml(fighter.name)}${badge}`;
    return `<div class="fighter ${side}">${name}${record}</div>`;
  }

  function renderBout(bout) {
    const [a = { name: "TBD" }, b = { name: "TBD" }] = bout.fighters;
    const middle = [bout.weight_class, bout.status.state === "in" ? "Live" : bout.result || bout.status.detail]
      .filter(Boolean)
      .map(escapeHtml)
      .join("<br>");
    return `
      <div class="bout">
        ${renderFighter(a, "left")}
        <div class="middle">${middle}</div>
        ${renderFighter(b, "right")}
      </div>`;
  }

  function renderFightCard(card) {
    const bouts = state.filter === "all" ? card.bouts : card.bouts.filter((b) => b.status.state === state.filter);
    const sub = [statusLabel(card.status, card.start_time), card.venue && escapeHtml(card.venue)].filter(Boolean).join(" &middot; ");
    const link = safeUrl(card.link);
    return `
      <article class="card fight-card">
        <h2>${escapeHtml(card.name)}</h2>
        <p class="sub">${sub}</p>
        ${bouts.length ? bouts.map(renderBout).join("") : `<p class="sub">No bouts match this filter.</p>`}
        ${link ? `<div class="card-foot"><span></span><a href="${escapeHtml(link)}" target="_blank" rel="noopener">Full card</a></div>` : ""}
      </article>`;
  }

  function renderScoreboard(data) {
    const events = data.events || [];
    if (!events.length) {
      showMessage(`No ${escapeHtml(data.league.name)} events scheduled for this date.`);
      return;
    }

    if (data.league.kind === "combat") {
      const cards = state.filter === "all" ? events : events.filter((c) => c.bouts.some((b) => b.status.state === state.filter) || c.status.state === state.filter);
      el.content.innerHTML = cards.length ? cards.map(renderFightCard).join("") : "";
      if (!cards.length) showMessage("No events match this filter.");
      return;
    }

    // Live games first, then upcoming, then finished.
    const order = { in: 0, pre: 1, post: 2 };
    const games = events
      .filter((g) => state.filter === "all" || g.status.state === state.filter)
      .sort((a, b) => order[a.status.state] - order[b.status.state] || String(a.start_time).localeCompare(String(b.start_time)));

    if (!games.length) {
      showMessage("No games match this filter.");
      return;
    }
    el.content.innerHTML = `<div class="grid">${games.map(renderGame).join("")}</div>`;
  }

  function renderFantasy(data) {
    const league = data.league;
    const standings = league.standings
      .map((t, i) => `
        <tr>
          <td>${i + 1}</td>
          <td>${escapeHtml(t.name)}</td>
          <td class="num">${t.wins}-${t.losses}${t.ties ? `-${t.ties}` : ""}</td>
          <td class="num">${t.points_for.toFixed(1)}</td>
          <td class="num">${t.points_against.toFixed(1)}</td>
        </tr>`)
      .join("");

    const side = (s, isLoser) => s ? `
      <div class="team-row${isLoser ? " is-loser" : ""}">
        <span class="team-name">${escapeHtml(s.team_name)}</span>
        <span class="score">${s.points.toFixed(2)}</span>
      </div>` : `<div class="team-row"><span class="team-name">Bye</span><span></span></div>`;

    const matchups = league.matchups.length
      ? league.matchups.map((m) => `
          <div class="matchup${m.winner !== "UNDECIDED" ? " is-final" : ""}">
            ${side(m.away, m.winner === "HOME")}
            ${side(m.home, m.winner === "AWAY")}
          </div>`).join("")
      : `<p class="sub">No matchups for week ${league.week}.</p>`;

    el.content.innerHTML = `
      <div class="fantasy-layout">
        <section class="card">
          <h2>${escapeHtml(league.name)} &middot; ${league.season} Standings</h2>
          <div class="table-wrap">
            <table>
              <thead><tr><th>#</th><th>Team</th><th class="num">Record</th><th class="num">PF</th><th class="num">PA</th></tr></thead>
              <tbody>${standings}</tbody>
            </table>
          </div>
        </section>
        <section class="card">
          <h2>Week ${league.week} Matchups</h2>
          ${matchups}
        </section>
      </div>`;
  }

  // Loading -----------------------------------------------------------------

  async function loadScoreboard() {
    const params = new URLSearchParams();
    if (state.date) params.set("date", state.date.replaceAll("-", ""));
    const data = await fetchJson(`/api/scoreboard/${state.league}?${params}`);
    state.lastScoreboard = data;
    renderScoreboard(data);
    setUpdated(data.updated_at);
    scheduleRefresh(data.live);
  }

  async function loadFantasy() {
    const params = new URLSearchParams();
    const leagueId = el.fantasyLeagueId.value.trim();
    const week = el.fantasyWeek.value.trim();
    if (leagueId) params.set("league_id", leagueId);
    if (week) params.set("week", week);
    const data = await fetchJson(`/api/fantasy?${params}`);
    renderFantasy(data);
    setUpdated(data.updated_at);
    // Fantasy scores only move while NFL games are on, so the idle interval is enough.
    scheduleRefresh(false);
  }

  async function load() {
    clearTimeout(state.timer);
    try {
      if (state.kind === "fantasy") await loadFantasy();
      else await loadScoreboard();
    } catch (err) {
      if (err.name === "AbortError") return;
      if (state.kind === "fantasy" && /No fantasy league configured/.test(err.message)) {
        showMessage("Enter your ESPN fantasy football league ID above, or set <code>ESPN_FANTASY_LEAGUE_ID</code> on the server.");
      } else {
        showMessage(escapeHtml(err.message), true);
      }
      setUpdated(null);
      scheduleRefresh(false);
    }
  }

  function selectLeague(tab) {
    el.tabs.forEach((t) => t.setAttribute("aria-selected", String(t === tab)));
    state.league = tab.dataset.league;
    state.kind = tab.dataset.kind;
    state.lastScoreboard = null;
    const isFantasy = state.kind === "fantasy";
    el.scoreboardToolbar.classList.toggle("is-hidden", isFantasy);
    el.fantasyToolbar.classList.toggle("is-hidden", !isFantasy);
    history.replaceState(null, "", `#${state.league}`);
    showMessage("Loading...");
    load();
  }

  function setDate(isoDate) {
    state.date = isoDate;
    state.lastScoreboard = null;
    el.datePicker.value = isoDate || "";
    showMessage("Loading...");
    load();
  }

  // Events ------------------------------------------------------------------

  el.tabs.forEach((tab) => tab.addEventListener("click", () => selectLeague(tab)));

  // Hide logos that fail to load instead of showing a broken image.
  el.content.addEventListener("error", (event) => {
    if (event.target.tagName === "IMG") event.target.style.visibility = "hidden";
  }, true);

  el.chips.forEach((chip) =>
    chip.addEventListener("click", () => {
      el.chips.forEach((c) => c.classList.toggle("is-active", c === chip));
      state.filter = chip.dataset.filter;
      if (state.lastScoreboard) renderScoreboard(state.lastScoreboard);
      else load();
    })
  );

  el.datePicker.addEventListener("change", () => setDate(el.datePicker.value || null));
  el.todayBtn.addEventListener("click", () => setDate(null));
  el.shiftBtns.forEach((btn) =>
    btn.addEventListener("click", () => {
      const base = state.date ? new Date(`${state.date}T12:00:00`) : new Date();
      base.setDate(base.getDate() + Number(btn.dataset.shift));
      setDate(toIsoDate(base));
    })
  );

  el.fantasyForm.addEventListener("submit", (event) => {
    event.preventDefault();
    try { localStorage.setItem(STORAGE_KEY, el.fantasyLeagueId.value.trim()); } catch { /* storage unavailable */ }
    showMessage("Loading...");
    load();
  });

  document.addEventListener("visibilitychange", () => {
    if (document.hidden) clearTimeout(state.timer);
    else if (state.league) load();
  });

  try { el.fantasyLeagueId.value = localStorage.getItem(STORAGE_KEY) || ""; } catch { /* storage unavailable */ }

  const initial = [...el.tabs].find((t) => `#${t.dataset.league}` === location.hash) || el.tabs[0];
  selectLeague(initial);
})();
