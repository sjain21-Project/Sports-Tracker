import json
from pathlib import Path

import pytest

from sports_tracker import create_app
from sports_tracker.config import Settings

FIXTURES = Path(__file__).parent / "fixtures"


def load_fixture(name: str) -> dict:
    return json.loads((FIXTURES / name).read_text())


class FakeClient:
    """Stands in for ESPNClient so tests never touch the network."""

    def __init__(self) -> None:
        self.scoreboards: dict[str, dict] = {}
        self.fantasy: dict | None = None
        self.error = None
        self.calls: list[tuple] = []

    def scoreboard(self, league, date=None):
        self.calls.append(("scoreboard", league.key, date))
        if self.error:
            raise self.error
        return self.scoreboards.get(league.key, {"events": []})

    def fantasy_league(self, league_id, season, week=None, espn_s2=None, swid=None):
        self.calls.append(("fantasy", league_id, season, week))
        if self.error:
            raise self.error
        return self.fantasy or {}


@pytest.fixture
def fake_client():
    return FakeClient()


@pytest.fixture
def make_client(fake_client):
    def _make(**settings):
        app = create_app(Settings(**settings), client=fake_client)
        app.testing = True
        return app.test_client()

    return _make
