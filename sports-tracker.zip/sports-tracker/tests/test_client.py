from unittest.mock import MagicMock

import pytest
import requests

from sports_tracker.espn.client import ESPNClient, ESPNError, TTLCache
from sports_tracker.leagues import LEAGUES


def _response(status=200, payload=None):
    response = MagicMock()
    response.status_code = status
    response.ok = 200 <= status < 300
    response.json.return_value = payload if payload is not None else {"events": []}
    return response


def test_scoreboard_builds_espn_url_and_params():
    session = MagicMock()
    session.headers = {}
    session.get.return_value = _response()

    ESPNClient(session=session).scoreboard(LEAGUES["ncaam"], "20261120")

    url = session.get.call_args.args[0]
    params = session.get.call_args.kwargs["params"]
    assert url.endswith("/basketball/mens-college-basketball/scoreboard")
    assert params == {"groups": "50", "limit": "300", "dates": "20261120"}


def test_responses_are_cached():
    session = MagicMock()
    session.headers = {}
    session.get.return_value = _response()
    client = ESPNClient(session=session)

    client.scoreboard(LEAGUES["nba"])
    client.scoreboard(LEAGUES["nba"])

    assert session.get.call_count == 1


def test_network_errors_become_espn_errors():
    session = MagicMock()
    session.headers = {}
    session.get.side_effect = requests.ConnectionError("down")

    with pytest.raises(ESPNError):
        ESPNClient(session=session).scoreboard(LEAGUES["nfl"])


def test_auth_errors_keep_status_code():
    session = MagicMock()
    session.headers = {}
    session.get.return_value = _response(status=401)

    with pytest.raises(ESPNError) as info:
        ESPNClient(session=session).fantasy_league("1", 2026)

    assert info.value.status_code == 401


def test_fantasy_sends_cookies_only_when_both_are_set():
    session = MagicMock()
    session.headers = {}
    session.get.return_value = _response(payload={})
    client = ESPNClient(session=session)

    client.fantasy_league("1", 2026, espn_s2="abc")
    assert session.get.call_args.kwargs["cookies"] == {}

    client.fantasy_league("1", 2026, week=3, espn_s2="abc", swid="{xyz}")
    assert session.get.call_args.kwargs["cookies"] == {"espn_s2": "abc", "SWID": "{xyz}"}
    assert session.get.call_args.kwargs["params"]["scoringPeriodId"] == "3"


def test_ttl_cache_expires(monkeypatch):
    now = [100.0]
    monkeypatch.setattr("sports_tracker.espn.client.time.monotonic", lambda: now[0])
    cache = TTLCache(ttl_seconds=10)

    cache.set("key", "value")
    assert cache.get("key") == "value"
    now[0] += 11
    assert cache.get("key") is None
