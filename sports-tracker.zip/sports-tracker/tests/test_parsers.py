from sports_tracker.espn import parsers

from .conftest import load_fixture


def test_team_scoreboard_orders_away_team_first():
    games = parsers.parse_team_scoreboard(load_fixture("nba_scoreboard.json"))

    assert len(games) == 2
    live = games[0]
    assert live.name == "BOS @ NY"
    assert [c.abbreviation for c in live.competitors] == ["BOS", "NY"]
    assert live.competitors[0].score == "81"
    assert live.competitors[0].record == "5-1"


def test_live_status_includes_clock_and_period():
    game = parsers.parse_team_scoreboard(load_fixture("nba_scoreboard.json"))[0]

    assert game.status.state == "in"
    assert game.status.detail == "4:12 - 3rd"
    assert game.status.clock == "4:12"
    assert game.status.period == 3
    assert game.venue == "Madison Square Garden"
    assert game.broadcast == "ESPN"
    assert game.link.endswith("401705001")


def test_final_game_marks_winner():
    final = parsers.parse_team_scoreboard(load_fixture("nba_scoreboard.json"))[1]

    assert final.status.state == "post"
    assert final.status.clock is None
    winners = [c.name for c in final.competitors if c.winner]
    assert winners == ["Denver Nuggets"]


def test_unranked_college_teams_have_no_rank():
    game = parsers.parse_team_scoreboard(load_fixture("ncaaf_scoreboard.json"))[0]
    ranks = {c.abbreviation: c.rank for c in game.competitors}

    assert ranks == {"OSU": 3, "MICH": None}


def test_fight_card_lists_main_event_first():
    card = parsers.parse_combat_scoreboard(load_fixture("ufc_scoreboard.json"))[0]

    assert card.name == "UFC Fight Night: Smith vs. Jones"
    assert card.venue == "UFC APEX"
    assert [b.weight_class for b in card.bouts] == ["Middleweight", "Lightweight"]
    main_event = card.bouts[0]
    assert main_event.result == "Decision - Unanimous"
    assert [f.name for f in main_event.fighters if f.winner] == ["Dan Jones"]


def test_parsers_tolerate_empty_payloads():
    assert parsers.parse_team_scoreboard({}) == []
    assert parsers.parse_combat_scoreboard({"events": None}) == []

    sparse = parsers.parse_game({"id": 1, "competitions": [{"competitors": [{}]}]})
    assert sparse.status.state == "pre"
    assert sparse.competitors[0].name == "TBD"


def test_fantasy_league_standings_and_current_week():
    league = parsers.parse_fantasy_league(load_fixture("fantasy_league.json"), "123456")

    assert league.name == "Sunday League"
    assert league.week == 9
    assert [t.name for t in league.standings] == ["Gridiron Bears", "Hawks"]
    assert len(league.matchups) == 1

    matchup = league.matchups[0]
    assert matchup.home.team_name == "Gridiron Bears"
    assert matchup.home.points == 64.38
    assert matchup.away.points == 71.1
    assert matchup.winner == "UNDECIDED"


def test_fantasy_week_override():
    league = parsers.parse_fantasy_league(load_fixture("fantasy_league.json"), "123456", week=8)

    assert league.week == 8
    assert league.matchups[0].winner == "HOME"
    assert league.matchups[0].home.points == 120.5
