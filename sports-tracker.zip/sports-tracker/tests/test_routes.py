from sports_tracker.espn.client import ESPNError

from .conftest import load_fixture


def test_index_renders_every_league_tab(make_client):
    response = make_client().get("/")
    html = response.get_data(as_text=True)

    assert response.status_code == 200
    for name in ("NFL", "NBA", "NCAA Football", "NCAA Men&#39;s Basketball", "UFC", "Boxing", "Fantasy Football"):
        assert name in html


def test_scoreboard_returns_parsed_games(make_client, fake_client):
    fake_client.scoreboards["nba"] = load_fixture("nba_scoreboard.json")

    body = make_client().get("/api/scoreboard/nba").get_json()

    assert body["league"]["key"] == "nba"
    assert body["live"] is True
    assert len(body["events"]) == 2


def test_scoreboard_passes_date_through(make_client, fake_client):
    make_client().get("/api/scoreboard/nfl?date=20261108")

    assert fake_client.calls == [("scoreboard", "nfl", "20261108")]


def test_combat_scoreboard_returns_fight_cards(make_client, fake_client):
    fake_client.scoreboards["ufc"] = load_fixture("ufc_scoreboard.json")

    body = make_client().get("/api/scoreboard/ufc").get_json()

    assert body["league"]["kind"] == "combat"
    assert len(body["events"][0]["bouts"]) == 2


def test_unknown_league_is_404(make_client):
    assert make_client().get("/api/scoreboard/mlb").status_code == 404


def test_bad_date_is_400(make_client):
    assert make_client().get("/api/scoreboard/nba?date=2026-11-05").status_code == 400


def test_upstream_failure_is_502(make_client, fake_client):
    fake_client.error = ESPNError("Could not reach ESPN.")

    response = make_client().get("/api/scoreboard/nba")

    assert response.status_code == 502
    assert response.get_json()["error"] == "Could not reach ESPN."


def test_fantasy_requires_league_id(make_client):
    response = make_client().get("/api/fantasy")

    assert response.status_code == 400
    assert "ESPN_FANTASY_LEAGUE_ID" in response.get_json()["error"]


def test_fantasy_uses_configured_league(make_client, fake_client):
    fake_client.fantasy = load_fixture("fantasy_league.json")

    response = make_client(fantasy_league_id="123456", fantasy_season=2026).get("/api/fantasy")
    body = response.get_json()

    assert response.status_code == 200
    assert body["league"]["name"] == "Sunday League"
    assert fake_client.calls == [("fantasy", "123456", 2026, None)]


def test_fantasy_private_league_is_403(make_client, fake_client):
    fake_client.error = ESPNError("ESPN denied access.", status_code=401)

    response = make_client().get("/api/fantasy?league_id=42")

    assert response.status_code == 403


def test_fantasy_rejects_non_numeric_id(make_client):
    assert make_client().get("/api/fantasy?league_id=abc").status_code == 400
